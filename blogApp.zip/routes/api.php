<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\Api\CommentApiController;
use App\Http\Controllers\Api\TagApiController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:api')->group(function () {
    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/logout', [AuthController::class, 'logout']);
});

Route::middleware('auth:api')->group(function () {
    Route::get('/posts', [PostController::class, 'indexApi']);
    Route::post('/posts', [PostController::class, 'storeApi']);
    Route::put('/posts/{post}', [PostController::class, 'update']);
    Route::put('/posts/{id}', [PostController::class, 'updateApi']);
    Route::delete('/posts/{id}', [PostController::class, 'destroyApi']);

    Route::post('/posts/{post}/comments', [CommentApiController::class, 'store']);
    Route::put('/comments/{comment}', [CommentApiController::class, 'update']);
    Route::delete('/comments/{comment}', [CommentApiController::class, 'destroy']);

    Route::get('/tags', [TagApiController::class, 'index']);
    Route::post('/tags', [TagApiController::class, 'store']);
    Route::put('/tags/{tag}', [TagApiController::class, 'update']);
    Route::delete('/tags/{tag}', [TagApiController::class, 'destroy']);
});
