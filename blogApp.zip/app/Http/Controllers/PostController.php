<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class PostController extends Controller
{
    public function indexApi()
    {
        
        $posts = Post::with('user')->latest()->get();

        return response()->json($posts, 200);
        
    }
    public function storeApi(Request $request)
    {
        $request->validate([
            'title' => 'required|string',
            'content' => 'required|string'
        ]);

        $post = Post::create([
            'user_id' => auth()->id(), // Ensure you're authenticated
            'title' => $request->title,
            'content' => $request->content
        ]);

        //return response()->json($post, 201);

        if (!empty($validated['tags'])) {
            $post->tags()->attach($validated['tags']);
        }
    
        return response()->json([
            'message' => 'Post created',
            'post' => $post->load('tags') 
        ], 201);
        
    }
    public function update(Request $request, Post $post)
{
    // Optional: authorize user
    if ($post->user_id !== $request->user()->id) {
        return response()->json(['message' => 'Unauthorized.'], 403);
    }

    $validated = $request->validate([
        'title' => 'required|string|max:255',
        'body' => 'required|string',
        'tags' => 'array',
        'tags.*' => 'exists:tags,id',
    ]);

    $post->update([
        'title' => $validated['title'],
        'body' => $validated['body'],
    ]);

    if (isset($validated['tags'])) {
        $post->tags()->sync($validated['tags']);
    }

    return response()->json([
        'message' => 'Post updated',
        'post' => $post->load('tags')
    ]);
}
    public function show(Post $post)
    {
        return response()->json([
            'id' => $post->id,
            'title' => $post->title,
            'content' => $post->content,
            'user_id' => $post->user_id,
            'created_at' => $post->created_at,
        ]);
    }
    public function destroyApi($id)
{
    $post = Post::find($id);

    if (!$post) {
        return response()->json([
            'message' => 'Post not found.'
        ], 404);
    }

    // Optional: check if the authenticated user owns the post
    if ($post->user_id !== auth()->id()) {
        return response()->json([
            'message' => 'Unauthorized.'
        ], 403);
    }

    $post->delete();

    return response()->json([
        'message' => 'Post deleted successfully.'
    ], 200);
}
}
