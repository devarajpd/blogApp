<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
    <title>Login</title>
    <style>
    .bg-purple {
    background-color: var(--purple);
        }
        .padding {
    padding: 5rem;
}
    </style>
</head>
<body class="bg-purple">
<div class="container padding">
    <div class="row">
        <div class="col-md-12 min-vh-100 d-flex flex-column justify-content-center">
            <div class="row">
                <div class="col-lg-6 col-md-8 mx-auto">

                    <!-- form card login -->
                    <div class="card rounded shadow shadow-sm">
                        <div class="card-header">
                            <h3 class="mb-0">Login</h3>
                        </div>
                        <div class="card-body">
                        <form id="login-form">
                                <div class="form-group">
                                    <label for="uname1">Email ID</label>
                                    <input class="form-control form-control-lg rounded-0"  type="email" id="email" placeholder="Email" required>
                                    <div class="invalid-feedback">Oops, you missed this one.</div>
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" class="form-control form-control-lg rounded-0" id="password" placeholder="Password" required>
                                    <div class="invalid-feedback">Enter your password too!</div>
                                </div>
                                <div>
                                    <label class="custom-control custom-checkbox">
                                      <input type="checkbox" class="custom-control-input">
                                      <span class="custom-control-indicator"></span>
                                      <span class="custom-control-description small text-dark">
                                      </span>
                                    </label>
                                </div>
                                <button type="submit" class="btn btn-success btn-lg float-right" id="btnLogin">Login</button>
                            </form>
                        </div>
                        <!--/card-block-->
                    </div>
                    <!-- /form card login -->

                </div>


            </div>
            <!--/row-->

        </div>
        <!--/col-->
    </div>
    <!--/row-->
</div>
<!--/container-->
<script>
document.getElementById('login-form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    if (response.ok) {
        //alert('Logged in! Token: ' + data);
        // Save token or redirect
        localStorage.setItem('access_token', data.access_token);

        // ✅ Redirect to dashboard page
        window.location.href = '/dashboard';
    } else {
        alert('Login failed: ' + (data.error || 'Unknown error'));
    }
});
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blogAppNew\resources\views/login.blade.php ENDPATH**/ ?>