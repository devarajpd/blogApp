<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
    <title>Login</title>
    <style>
    .bg-purple {
    background-color: var(--purple);
        }
        .padding {
    padding: 5rem;
}
    </style>
</head>
<body class="bg-purple">
<div class="container padding">
    <div class="row">
        <div class="col-md-12 min-vh-100 d-flex flex-column justify-content-center">
            <div class="row">
                <div class="col-lg-6 col-md-8 mx-auto">

                    <!-- form card login -->
                    <div class="card rounded shadow shadow-sm">
                        <div class="card-header">
                            <h3 class="mb-0">Register</h3>
                        </div>
                        <div class="card-body">
                        <form id="register-form">
                        <div class="form-group">
                                    <label for="uname1">Name</label>
                                    <input class="form-control form-control-lg rounded-0"  type="text" id="name" placeholder="Name" required>
                                    <div class="invalid-feedback">Oops, you missed this one.</div>
                                </div>
                                <div class="form-group">
                                    <label for="uname1">Email ID</label>
                                    <input class="form-control form-control-lg rounded-0"  type="email" id="email" placeholder="Email" required>
                                    <div class="invalid-feedback">Oops, you missed this one.</div>
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" class="form-control form-control-lg rounded-0"  id="password" placeholder="Password" required>
                                    <div class="invalid-feedback">Enter your password too!</div>
                                </div>
                                <div class="form-group">
                                    <label>Confirm Password</label>
                                    <input type="password" class="form-control form-control-lg rounded-0" id="password_confirmation" placeholder="Confirm Password" required>
                                    <div class="invalid-feedback">Enter your password too!</div>
                                </div>
                                <div>
                                    <label class="custom-control custom-checkbox">
                                      <input type="checkbox" class="custom-control-input">
                                      <span class="custom-control-indicator"></span>
                                      <span class="custom-control-description small text-dark">
                                      </span>
                                    </label>
                                </div>
                                <button type="submit" class="btn btn-success btn-lg float-right" id="btnLogin">Register</button>
                            </form>
                        </div>
                        <!--/card-block-->
                    </div>
                    <!-- /form card login -->

                </div>


            </div>
            <!--/row-->

        </div>
        <!--/col-->
    </div>
    <!--/row-->
</div>
<!--/container-->
<script>
document.getElementById('register-form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const password_confirmation = document.getElementById('password_confirmation').value;

    const response = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, password_confirmation })
    });

    const data = await response.json();

    if (response.ok) {
        //alert('Registration successful. Token: ' + data.access_token);
        localStorage.setItem('access_token', data.access_token);

        // ✅ Redirect to dashboard page
        window.location.href = '/dashboard';
    } else {
        alert('Error: ' + JSON.stringify(data));
    }
});
</script>
</body>
</html>
