<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Simple Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <style>
    body {
      min-height: 100vh;
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      padding-top: 20px;
    }
    .sidebar a {
      color: #adb5bd;
      display: block;
      padding: 10px 20px;
      text-decoration: none;
    }
    .sidebar a:hover {
      background-color: #495057;
      color: #fff;
    }
    .topbar {
      background-color: #fff;
      padding: 10px 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .content {
      padding: 20px;
    }
  </style>
</head>

<body>

<div class="container-fluid">
  <div class="row">
    
    <!-- Sidebar -->
    <nav class="col-md-2 d-none d-md-block sidebar">
      <div class="sidebar-sticky">
      <h5 class="text-white">Dashboard</h5>
        <a href="http://localhost:8000/dashboard">Home</a>
        <a href="http://localhost:8000/create-post">Add New Post</a>
        <a href="http://localhost:8000/dashboard">List All Post</a>
        <a href="http://localhost:8000/api/logout">Logout</a>
      </div>
    </nav>

    <!-- Main content -->
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
      
      <div class="topbar d-flex justify-content-between align-items-center">
        <h4 class="mb-0">Welcome to Dashboard</h4>
        <a href="/api/logout" class="btn btn-danger btn-sm">Logout</a>
      </div>

      <div class="content mt-4">
        <h5>Add Offer</h5>
        <form id="post-form" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= isset($offer) ? $offer['id'] : '' ?>">
          <div class="form-group">
            <label for="offerTitle">Post Title</label>
            <input type="text" class="form-control"  id="title" name="title" required value="<?= isset($offer) ? $offer['offerCode'] : '' ?>">
          </div>
          <div class="form-group">
            <label for="expiryDate">Tag</label>
            <input type="text" class="form-control" id="minimumSpend" name="minimumSpend" required value="<?= isset($offer) ? $offer['minimumSpend'] : '' ?>">
          </div>
          <div class="form-group">
            <label for="expiryDate">Descriptions</label>
            <textarea type="text" class="form-control" id="content" name="content" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Add Post</button>
        </form>
      </div>

    </main>

  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
 $('#post-form').submit(function(e) {
            e.preventDefault();
            const API_URL = 'http://localhost:8000/api/posts';
            const token = localStorage.getItem('access_token');
            alert(token);
            const id = $('#post-id').val();
            const title = $('#title').val();
            const content = $('#content').val();
            const method = id ? 'PUT' : 'POST';
            const url = id ? `${API_URL}/${id}` : API_URL;
            $.ajax({
                url: url,
                method: method,
                headers: {
                    Authorization: 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({ title, content }),
                success: function() {
                    $('#post-id').val('');
                    $('#title').val('');
                    $('#content').val('');
                    //fetchPosts();
                }
            });
        });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
